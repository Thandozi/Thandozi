try {
	const profile_tag = document.getElementById("profile_tag");
	const slide = document.getElementById("slide");

	var selector = Math.floor(Math.random() * 4);
	var tag = {"Image", "Video", "3D", "Code"}
	document.addEventListener("load", e => {
    	profile_tag.innerHTML = tag[selector];
    	slide.setAttribute("src", "./img/");
	});
} catch (err) {
    alert(err);
}
