try {
	/* Root Element */
	const navbar = document.getElementById("navbar");

	/* Branch Elements */
	const btnMenu = document.getElementById("btnMenu");
	const dropSlide_menu = document.getElementById("dropSlide_menu");
} catch (err) {
    alert("Nav: " + err);
}