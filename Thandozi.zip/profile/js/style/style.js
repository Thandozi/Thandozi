var profile_tag = document.querySelector("#stmnt");
console.log(Math.floor(Math.random()));
/*** Function profile_tag() {
    try {
    	var index = Math.round(Math.random());
    	var tags ["Image-rgb(20, 172, 115)", "Code-rgb(40, 90, 255)", "Write-rgb(135, 0, 92)"] 
    	//Image
    	if (tags[index] == 0) {
			profile_tag.innerHTML = tags[0].slice(0, tags[0].search("-"));
			profile_tag.style.color = tags[0].slice(tags[0].search("-"));
			console.log(tags[0]);
    	//Code
    	} else if (tag[index] == 1) {
    	    profile_tag.innerHTML = tags[1].slice(0, tags[1].search("-"));
    	    profile_tag.style.color = tag1[1].slice(tags[1].search("-"));
    	    console.log("Tag name:" + tags[1]);
    	} else if (tags[index] == 2) {
    	    profile_tag.innerHTML = tags[2].slice(0, tags[2].search("-"));
    	    profile_tag.style.color = tags[2].slice(tags[2].search("-"));
    	} else {
    	    console.log("An error had occurred!");
    	}
    	console.log("inside try" );
    	
    } catch(err) {
        console.log(err.name);
    }
}
***/