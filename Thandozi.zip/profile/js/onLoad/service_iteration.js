/*** variables ***/
//var service = document.querySelector("#profile_tag");

document.addEventListener("load", e => {
    var service = document.querySelector("#profile_tag");
    var profile_tag = ["Image", "Video", "Code", "Sound", "Write"];
    var randomIndex = Math.round(Math.random() * 6);
    alert(randomIndex);
    var tag = profile_tag[randomIndex]
    service.innerHTML = "test";
    switch(tag) {
        case "Video" :
            service.innerHTML = toString(tag);
            service.style.color = "green";
            break;
        case "Code" :
            service.innerHTML = toString(tag);
            service.style.color = "purple";
            break;
        case "Sound" :
            service.innerHTML = toString(tag);
            service.style.color = "blue";
            break;
        case "Write" :
            service.innerHTML = toString(tag);
            service.style.color = "orangered"
            break;
        default :
        		service.innerHTML = toString(tag);
        		service.style.color = "rgb(40, 172, 115)";
    } 
            
});
