import "./content_statement" 

/*** links ***/
let link_img = document.querySelector("#img_link");
let link_vid = document.querySelector("#link_vid");
let link_models = document.querySelector("#3dModels");
let link_code = document.querySelector("#link_code");
let links = document.querySelectorAll("links");

/*** changing elements ***/
let content_title = document.querySelector("#content_title");
let content_p = document.querySelector("#content_p");
let item_title = document.querySelector(".img_title");
/*** array of img elements ***/
let item_img = document.querySelector("im");
/*** array of b elements ***/
let price = document.querySelector();

/*** output ***/
let activeServ = document.querySelector(".active");

/*** Event Listeners ***/
links.addEventListener("touchstart", getLinkID); 
link_img.addEventListener("touchstart", setActive_content("link_img"));

/*** functions ***/
Function getLinkID() {
    link
}

Function setActive_content(linkID) and {
    try {
        if (linkID == "link_img") {
            /*** images ***/
            content_title.innerHTML = "Images";
            content_p.innerHTML = img_stmnt;
            for ( var i = 0; i < item_img.length; i++) {
                	item_title.innerHTML = "Image#" + i;
                	item_img[i].attr.src = "../img/default_img.png";
            } 
        } else if (linkID == "link_vid") {
            
    } catch (e) {
        console.log(e.name + e.error);
    }
