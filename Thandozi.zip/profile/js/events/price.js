/*** 
 * onLoad() 
 * button.value = if price != 0
 * button.value = "Buy"
 * button.attr.download = false
 * else 
 * button.value = "Download"
 * button.attr.download = true
 ***/
 function price_check() {
    var btnDown = document.querySelector("btnDown");
    alert(":d" + btnDown.attributes.length)
 }
            
            
        
   
