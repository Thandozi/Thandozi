/*** variables ***/
var btn_menu = document.querySelector("#btn_menu");
var menu_bars = document.querySelectorAll(".menu_bars");

btn_menu.addEventListener("touchstart", e => {
    	try {
    		/*** create menu and its content ***/
    		var menu = document.createElement("div");
    		//child elements
    		var menu_title = document.createElement("h1");
    		var menu_ul = document.createElement("ul");
    		var menu_li = document.createElement("li");
    		var menu_a = document.createElement("a");
    		
    		/*** element content ***/
    		// Child element content 
    		menu_title.innerHTML = "Menu";
    		
    		//link : service
    		menu_li.innerHTML = menu_a;
    		menu_a.setAttribute("href", "#service");
    		menu_a.innerHTML = "Service";
    		menu_ul.appendChild(menu_li);
    		
    		//link : about us
    		menu_a.innerHTML = "About us";
    		menu_a.setAttribute("href", "#about");
    		menu_li.innerHTML = menu_a;
    		menu_ul.appendChild(menu_li);
    		
    		//link : contact us
    		menu_a.innerHTML = "Contact us";
    		menu_a.setAttribute(menu_li);
    		menu_li.innerHTML= menu_a;
    		menu_ul.appendChild(menu_li);
    		// parent element
    		menu.appendChild(menu_title);
    		menu.appendChild(menu_ul);
    		document.appendChild(menu);
    		
    		//style
    		menu.style.backgroundColor = "whitesmoke";
    		menu.style.position = "absolute";
    		btn.style.backgroundColor = "red";
    		
    
    	} catch(err) {
    	    console.log(err.message);
    	    document.open();
    	    	document.write(err.message);
    	    document.close();
    	    btn_menu.style.backgroundColor = "whitesmoke";
    	    } 
});
    	
